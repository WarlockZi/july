-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `july` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `july`;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `comments` (`id`, `text`, `user_id`, `post_id`, `date`) VALUES
(152,	'A maiores est numquam eaque illo.',	40,	237,	'1986-08-23'),
(154,	'Quibusdam est neque voluptates eos facilis at et eos.',	40,	229,	'2002-09-06'),
(156,	'Beatae aut dolor rerum ea tenetur eum modi.',	48,	225,	'2002-10-31'),
(161,	'Maxime quos adipisci odit.',	42,	239,	'1986-12-18'),
(168,	'Eum commodi maiores quia modi quis error.',	40,	233,	'2006-08-20'),
(171,	'Dolor rem ea et nostrum soluta nemo in.',	37,	230,	'2020-10-03'),
(174,	'Officia illo illum aut.',	36,	236,	'2000-01-04'),
(176,	'Adipisci hic assumenda quia consectetur totam eum.',	47,	222,	'2011-05-15'),
(179,	'Laudantium est voluptate culpa et temporibus.',	40,	225,	'1978-06-13'),
(180,	'Earum repellendus delectus ut vel veniam.',	35,	238,	'1995-02-24'),
(181,	'Perferendis ut eaque at voluptatem et non.',	39,	227,	'1982-09-24'),
(182,	'Velit quibusdam reprehenderit illum qui vero.',	47,	229,	'1973-02-18'),
(183,	'Quaerat qui dicta ratione.',	38,	224,	'1970-12-06'),
(184,	'Ut rerum corporis laboriosam mollitia amet.',	48,	225,	'2001-04-30'),
(185,	'Rerum ea eum ipsum et consectetur.',	39,	236,	'1975-02-09'),
(189,	'Consequatur deleniti harum quis sit ipsam recusandae.',	41,	227,	'2012-06-04'),
(193,	'Cum et nam distinctio consequuntur hic quas.',	39,	219,	'2022-05-08'),
(195,	'Temporibus aut quod eos vel voluptas eveniet.',	40,	230,	'1996-09-14'),
(197,	'Quos est non non omnis eius.',	43,	239,	'2010-04-24'),
(199,	'Ut dolorum nemo et explicabo.',	37,	230,	'2020-10-03'),
(201,	'Quidem at qui quis eos sed dolor impedit.',	41,	227,	'1982-09-29'),
(202,	'Quam ipsa odio nesciunt omnis labore.',	45,	223,	'1994-04-30'),
(203,	'Et quis vel temporibus repellat autem non.',	36,	219,	'1975-07-07'),
(204,	'Iusto atque doloremque minima cupiditate molestias.',	49,	239,	'1999-05-20'),
(205,	'Rerum cupiditate earum dolor amet reiciendis.',	43,	220,	'1997-12-23'),
(206,	'Cumque et vitae rerum voluptatem.',	49,	220,	'1981-08-30'),
(207,	'Illo id dolore id officiis quae id maiores.',	45,	221,	'1979-07-01'),
(208,	'Veritatis id id ut accusamus.',	37,	233,	'1991-02-26'),
(209,	'Rem occaecati voluptatum in.',	35,	224,	'2009-06-23'),
(210,	'Magnam et sed quisquam harum et exercitationem.',	40,	232,	'2004-07-13'),
(211,	'Temporibus porro recusandae sit vero rerum a.',	36,	233,	'2021-12-15'),
(217,	'fdsafdaf  dfsa fd sa',	39,	229,	'2023-07-06'),
(224,	'fdsafdaf  dfsa fd sa',	39,	220,	'2023-07-07');

SET NAMES utf8mb4;

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `long_text` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_text` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2023-07-07 08:20:09
